package org.websites3;

import java.io.File;
import java.sql.Date;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class mobileresolution3 {
	public static void main(String[] args) {
		try {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\phoen\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();

			driver.manage().window().setSize(new org.openqa.selenium.Dimension(360, 640));
			driver.get("https://www.getcalley.com/see-a-demo/");
			
			 
		            
		            // Generate the current date and time for the filename
		            String timestamp = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date(0));
		            String fileName = "screenshot_" + timestamp + ".png";
		            
		            // Take the screenshot and store it as a file
		            TakesScreenshot screenshot = (TakesScreenshot) driver;
		            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
		            File destFile = new File("C:\\Users\\phoen\\eclipse-workspace\\Getcalley\\screenshots3\\0004"+timestamp+".png");
		            
		            // Save the screenshot
		            FileUtils.copyFile(srcFile, destFile);
		            
		            System.out.println("Screenshot saved as: " + fileName);
		        } catch (Exception e) {
		            e.printStackTrace();
		        
		        
	}

	try {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\phoen\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().setSize(new org.openqa.selenium.Dimension(414, 896));
		driver.get("https://www.getcalley.com/see-a-demo/");
		
		 
	            
	            // Generate the current date and time for the filename
	            String timestamp = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date(0));
	            String fileName = "screenshot_" + timestamp + ".png";
	            
	            // Take the screenshot and store it as a file
	            TakesScreenshot screenshot = (TakesScreenshot) driver;
	            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
	            File destFile = new File("C:\\Users\\phoen\\eclipse-workspace\\Getcalley\\screenshots\\0005"+timestamp+".png");
	            
	            // Save the screenshot
	            FileUtils.copyFile(srcFile, destFile);
	            
	            System.out.println("Screenshot saved as: " + fileName);
	        } catch (Exception e) {
	            e.printStackTrace();
	        
	        }

	try {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\phoen\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().setSize(new org.openqa.selenium.Dimension(375, 667));
		driver.get("https://www.getcalley.com/see-a-demo/");
		 
	            
	            // Generate the current date and time for the filename
	            String timestamp = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss").format(new Date(0));
	            String fileName = "screenshot_" + timestamp + ".png";
	            
	            // Take the screenshot and store it as a file
	            TakesScreenshot screenshot = (TakesScreenshot) driver;
	            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
	            File destFile = new File("C:\\Users\\phoen\\eclipse-workspace\\Getcalley\\screenshots3\\0006"+timestamp+".png");
	            
	            // Save the screenshot
	            FileUtils.copyFile(srcFile, destFile);
	            
	            System.out.println("Screenshot saved as: " + fileName);
	        } catch (Exception e) {
	            e.printStackTrace();
	        
	        }

	}
}
