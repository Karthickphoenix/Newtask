package org.Functionaltesting;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dealsdray {
	public static void main(String[] args) {
		try {
			System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\phoen\\Downloads\\chromedriver-win64 (2)\\chromedriver-win64\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://demo.dealsdray.com/");

			driver.manage().window().maximize();
			
			
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@name='username']")).sendKeys("prexo.mis@dealsdray.com");
			driver.findElement(By.name("password")).sendKeys("prexo.mis@dealsdray.com");
			driver.findElement(By.xpath("//*[text()='Login']")).click();
			Thread.sleep(3000);
			WebElement order= driver .findElement(By.xpath("//*[text()='54']"));
			order.click();
			System.out.println("successfully clicked orders");
			Thread.sleep(3000);
			WebElement bulkorders =driver.findElement(By.xpath("//*[text()='Add Bulk Orders']"));
			bulkorders.click();
			System.out.println("successfully clicked");
			Thread.sleep(9000);
			WebElement choosefile= driver.findElement(By.xpath("//*[@id='mui-40']"));
			choosefile.click();
			System.out.println("successfully cliked");
			 driver.get("https://example.com/upload");

		        WebElement uploadElement = driver.findElement(By.id("file-upload"));

		        uploadElement.sendKeys("C:\\Users\\phoen\\Downloads\\demo-data.xlsx");


		        WebElement submitButton = driver.findElement(By.id("submit-button"));
		        submitButton.click();
		       
	            TakesScreenshot screenshot = (TakesScreenshot) driver;
	            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
	            File destFile = new File("C:\\Users\\phoen\\eclipse-workspace\\Getcalley\\screenshotstest.png");
	         
	            FileUtils.copyFile(srcFile, destFile);
	            
	         
		} catch (Exception e) {
			// TODO: handle exception.
		}

	}
}
